<?php
$mod_strings['LBL_LOGINAUDIT_ADMIN'] = 'Login Audit';
$mod_strings['LBL_LOGINAUDIT_DESCRIPTION'] = 'Login Audit List';
$mod_strings['LBL_LOGINAUDIT_GROUP'] = 'Login Audit';
$mod_strings['LBL_LOGINAUDIT_GROUP_DESCRIPTION'] = '';
